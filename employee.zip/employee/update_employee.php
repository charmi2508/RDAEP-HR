<?php

include "DBconnect.php"; 

$id = isset($_GET['id']) ? intval($_GET['id']) : 0; 

if ($id > 0) {
    
    $stmt = $conn->prepare("SELECT * FROM employee WHERE id = ? AND Isdelete = 0");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

 
    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();
    } else {
        die("Record not found.");
    }
    $stmt->close();
} else {
    die("Invalid ID.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employee</title>
     <link rel="stylesheet" href="style.css"> 
</head>
<body>
    <h1>Update Employee</h1>

    <form action="employee.php" method="POST" enctype="multipart/form-data">

        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?php echo $employee['id']; ?>">

        <div class="row">
        <div>
            <label>First Name:</label>
           <input type="text" name="first_name" value="<?php echo $employee['first_name']; ?>" required>
        </div>
        <div>
            <label>Last Name:</label>
             <input type="text" name="last_name" value="<?php echo $employee['last_name']; ?>" required>
        </div>
    </div>
        <div class="input-group">
        <div class="country-code">
            <label>Country Code:</label>
            <select name="country_code" required>
            <option value="+1" <?php echo $employee['country_code'] == '+1' ? 'selected' : ''; ?>>+1</option>
            <option value="+91" <?php echo $employee['country_code'] == '+91' ? 'selected' : ''; ?>>+91 </option>
            <option value="+44" <?php echo $employee['country_code'] == '+44' ? 'selected' : ''; ?>>+44 </option>
            <option value="+81" <?php echo $employee['country_code'] == '+81' ? 'selected' : ''; ?>>+81 </option>
            <option value="+86"<?php echo $employee['country_code'] == '+86' ? 'selected' : ''; ?>>+86 </option>
              
            </select>
        </div>
        <div>
            <label>Mobile:</label>
            <input type="number" name="mobile" value="<?php echo $employee['mobile']; ?>" required>
        </div>
    </div>
        <div class="row">
        <div>
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo $employee['email']; ?>" required>
        </div>
        <div>
            <label>Address:</label>
            <textarea name="address" required><?php echo $employee['address']; ?></textarea>
        </div>
    </div>

       
    <div class="row">
    <div>
        <label>Gender:</label>
        <input type="radio" name="gender" value="Male" <?php echo ($employee['gender'] ?? '') == 'Male' ? 'checked' : ''; ?>> Male
        <input type="radio" name="gender" value="Female" <?php echo ($employee['gender'] ?? '') == 'Female' ? 'checked' : ''; ?>> Female
        <input type="radio" name="gender" value="Other" <?php echo ($employee['gender'] ?? '') == 'Other' ? 'checked' : ''; ?>> Other
    </div>
    <div>
        <label>Hobbies:</label>
        <?php
        $hobbies = explode(", ", $employee['hobby'] ?? ''); 
        ?>
        <input type="checkbox" name="hobby[]" value="Reading" <?php echo in_array('Reading', $hobbies) ? 'checked' : ''; ?>> Reading
        <input type="checkbox" name="hobby[]" value="Traveling" <?php echo in_array('Traveling', $hobbies) ? 'checked' : ''; ?>> Traveling
        <input type="checkbox" name="hobby[]" value="Cooking" <?php echo in_array('Cooking', $hobbies) ? 'checked' : ''; ?>> Cooking
    </div>
</div>

        <label>Photo:</label>
        <input type="file" name="photo" accept="image/*">

        <input type="submit" value="Update Employee">
    </form>

    <a href="employee.php">Back to Employee List</a>
</body>
</html>
