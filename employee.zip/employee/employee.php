<?php
include "DBconnect.php";
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    function sanitizeInput($conn, $data) {
        if (is_array($data)) {
            return implode(',', array_map(function($item) use ($conn) {
                return $conn->real_escape_string(trim($item));
            }, $data));
        }
        return $conn->real_escape_string(trim($data));
    }

    if ($action == 'insert') {
        $first_name = sanitizeInput($conn, $_POST['first_name']);
        $last_name = sanitizeInput($conn, $_POST['last_name']);
        $country_code = sanitizeInput($conn, $_POST['country_code']);
        $mobile = sanitizeInput($conn, $_POST['mobile']);
        $email = sanitizeInput($conn, $_POST['email']);
        $address = sanitizeInput($conn, $_POST['address']);
        $gender = sanitizeInput($conn, $_POST['gender']);
        $hobby = sanitizeInput($conn, $_POST['hobby']); 

        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $photo = $_FILES['photo'];
            $photoPath = 'uploads/' . basename($photo['name']);

            
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true); 
            }

            // Allowed file types and size
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($photo['type'], $allowedTypes) && $photo['size'] <= 2000000) {
                if (move_uploaded_file($photo['tmp_name'], $photoPath)) {
                    $stmt = $conn->prepare("INSERT INTO employee (first_name, last_name, country_code, mobile, email, address, gender, hobby, photo, Isdelete) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
                    $stmt->bind_param("sssssssss", $first_name, $last_name, $country_code, $mobile, $email, $address, $gender, $hobby, $photoPath);

                    if ($stmt->execute()) {
                        $message = "New record created successfully.";
                    } else {
                        $message = "Error: " . $stmt->error;
                    }
                    $stmt->close();
                } else {
                    $message = "Sorry, there was an error uploading your file.";
                }
            } else {
                $message = "Invalid file type or size exceeded.";
            }
        } else {
            $message = "File upload error: " . $_FILES['photo']['error'];
        }
    }

    if ($action == 'update') {
        $id = intval($_POST['id']);
        $first_name = sanitizeInput($conn, $_POST['first_name']);
        $last_name = sanitizeInput($conn, $_POST['last_name']);
        $country_code = sanitizeInput($conn, $_POST['country_code']);
        $mobile = sanitizeInput($conn, $_POST['mobile']);
        $email = sanitizeInput($conn, $_POST['email']);
        $address = sanitizeInput($conn, $_POST['address']);
        $gender = sanitizeInput($conn, $_POST['gender']);
        $hobby = sanitizeInput($conn, $_POST['hobby']);

        $stmt = $conn->prepare("UPDATE employee SET first_name=?, last_name=?, country_code=?, mobile=?, email=?, address=?, gender=?, hobby=? WHERE id=? AND Isdelete=0");
        $stmt->bind_param("ssssssssi", $first_name, $last_name, $country_code, $mobile, $email, $address, $gender, $hobby, $id);

        if ($stmt->execute()) {
            $message = "Record updated successfully.";
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }

    if ($action == 'delete') {
        $id = intval($_POST['id']);

        $stmt = $conn->prepare("UPDATE employee SET Isdelete = 1 WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $message = "Record deleted successfully.";
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$sql = "SELECT * FROM employee WHERE Isdelete = 0";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link rel="stylesheet" href="style.css"> 
</head>
<body>

<h1>Employee Management</h1>

<?php if (!empty($message)): ?>
    <div class="message <?php echo strpos($message, 'Error') !== false ? 'error' : 'success'; ?>">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<!-- Insert Form -->
<form action="employee.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="action" value="insert">

    <div class="row">
        <div>
            <label>First Name:</label>
            <input type="text" name="first_name" required autocomplete="off">
        </div>
        <div>
            <label>Last Name:</label>
            <input type="text" name="last_name" required autocomplete="off">
        </div>
    </div>
    <div class="row">
        <div>
            <label>Country Code:</label>
            <select name="country_code" required>
                <option value="+1">+1</option>
				<option value="+91">+91</option>
				<option value="+44">+44</option>				
				<option value="+81">+81</option>
				<option value="+86">+86</option>
              
            </select>
        </div>
        <div>
            <label>Mobile:</label>
            <input type="number" name="mobile" required autocomplete="off">
        </div>
    </div>

    <div class="row">
        <div>
            <label>Email:</label>
            <input type="email" name="email" required autocomplete="off">
        </div>
        <div>
            <label>Address:</label>
            <textarea name="address" required autocomplete="off"></textarea>
        </div>
    </div>

    <div class="row">
        <div>
            <label>Gender:</label>
            <input type="radio" name="gender" value="Male" required> Male
            <input type="radio" name="gender" value="Female"> Female
            <input type="radio" name="gender" value="Other"> Other
        </div>
        <div>
            <label>Hobbies:</label>
            <input type="checkbox" name="hobby[]" value="Reading"> Reading
            <input type="checkbox" name="hobby[]" value="Traveling"> Traveling
            <input type="checkbox" name="hobby[]" value="Cooking"> Cooking
        </div>
    </div>

    <label>Photo:</label>
    <input type="file" name="photo" accept="image/*" required>

    <input type="submit" value="Add Employee">
</form>

<h2>Employee List</h2>
<div class="table-responsive">
    <table class="center-table">
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Country Code</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Address</th>
            <th>Gender</th>
            <th>Hobby</th>
            <th>Photo</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['first_name']; ?></td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['country_code']; ?></td>
                <td><?php echo $row['mobile']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                <td><?php echo $row['hobby']; ?></td>
                <td><img src="<?php echo $row['photo']; ?>" alt="Employee Photo" width="50"></td>
                <td>
                    <form action="update_employee.php" method="GET" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="submit" value="Edit">
                    </form>
                </td>
                <td>
                    <form action="employee.php" method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="submit" value="Delete" style="background: #ff00009e;" onclick="return confirm('Are you sure?');">
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>
